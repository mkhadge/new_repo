package ESB;


import java.io.IOException;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;


public class XMLValidator {
		
	public static synchronized void validate(String xmlString, String xsdString) throws SAXException, IOException{
        
		SchemaFactory factory = 
		SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Source xsdSource = new StreamSource(new StringReader(xsdString));
        Schema schema = factory.newSchema(xsdSource); 
            
        Validator validator = schema.newValidator();
        Source xmlStreamSource = new StreamSource(new StringReader(xmlString));
        validator.validate(xmlStreamSource);
   
	}
	
	public static void main (String[] args) throws Exception{
		
		
		/*
		//for testing only
		String xmlString = "<test><user1>abc</user1><ip>abc</ip><origin>abc</origin></test>";
		String xsdString = "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" attributeFormDefault=\"unqualified\" elementFormDefault=\"qualified\"><xs:element name=\"test\" type=\"test\"/><xs:complexType name=\"test\"><xs:sequence><xs:element name=\"user\" type=\"xs:string\"/><xs:element name=\"ip\" type=\"xs:string\"/><xs:element name=\"origin\" type=\"xs:string\"/></xs:sequence></xs:complexType></xs:schema>";
		XMLValidator validator = new XMLValidator();
		validator.validate(xmlString, xsdString);
		*/
		
	}
}

